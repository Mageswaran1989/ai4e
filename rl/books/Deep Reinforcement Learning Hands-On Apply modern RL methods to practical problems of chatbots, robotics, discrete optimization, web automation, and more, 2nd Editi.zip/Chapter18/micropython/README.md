This directory includes Micropython boad definition file changes I need to do 
to make SD card working on my board with the latest firmware.

Directory `PYBV11_my` need to be copied to `ports/stm32/boards` and used during the firmware build.
Files is this directory is the copy of `PYBV11` dir from MicroPython 1.11 release. To check the changes,
diff file is also included.
