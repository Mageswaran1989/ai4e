# Multi-agent chapter of the book

## Installation

```bash
git clone git@github.com:geek-ai/MAgent.git
```

Setup required prerequisites mentioned in https://github.com/geek-ai/MAgent

```bash
cd MAgent
bash build.sh
```


