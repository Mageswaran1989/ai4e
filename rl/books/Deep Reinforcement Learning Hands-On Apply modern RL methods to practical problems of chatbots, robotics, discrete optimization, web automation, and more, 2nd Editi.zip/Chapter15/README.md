Requires master branch of TextWorld. Reasons:
* latest gym
* bug with observations: https://github.com/microsoft/TextWorld/pull/157

Could be installed with `pip install git+https://github.com/microsoft/TextWorld`
